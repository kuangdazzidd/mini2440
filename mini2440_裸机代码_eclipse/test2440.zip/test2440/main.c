
int main()
{
    int i = 0;
    return 0;
}

